vabamorf
========

Eesti keele morfanalüsaator

Analüsaatori ja süntesaatori kompileerimis- ja kasutusjuhend failis doc/readme.html

LibreOffice'i spelleri kompileerimisjuhend failis apps/plugin/libreoffice/readme.txt

Java integratsiooninäite juhend failis apps/cmdline/java/readme.html
