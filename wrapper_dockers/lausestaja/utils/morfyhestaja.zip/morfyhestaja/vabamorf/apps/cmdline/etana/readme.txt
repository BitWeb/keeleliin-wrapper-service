Kasutamine
----------
etana k�ivitamine ilma parameetriteta kuvab k�sureaparameetrid koos seletusega.

Sisendfail
----------
Kodeering: UTF8, ilma BOM-ita
Struktuur:
{
	"paragraphs": [
		{
			"sentences": [
				{
					"words": [
						{
							"text": "string"
						},
						...
					]
				},
				...
			]
		},
		...
	]
}

V�ljundfail
-----------
Kodeering: UTF8, ilma BOM-ita
S�nadele (words[*]) lisatakse t�iendav informatsioon. 

Spelleri re�iimis:
"spelling": boolean,
"suggestions": [ "string", ...]

Anal�saatori re�iimis:
"analysis": [
	{
		"clitic": "string",
		"ending": "string",
		"form": "string",
		"partofspeech": "string",
		"root": "string"
	},
	...
]
