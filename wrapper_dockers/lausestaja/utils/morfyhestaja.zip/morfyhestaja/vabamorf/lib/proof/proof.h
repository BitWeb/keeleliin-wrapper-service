#if !defined _PROOF_H_ajfhasdjsfh_
#define _PROOF_H_ajfhasdjsfh_

#include "../etana/etmrf.h"

#include "pttype.h"
#include "ptword.h"
#include "suggestor.h"
#include "linguistic.h"

#endif // _PROOF_H_ajfhasdjsfh_
