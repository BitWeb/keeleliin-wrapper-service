// siia kataloogi tulevad asjad hiljem,
// vajalik, et tekkiks õige nimega teek,
// mida hiljem kasutada

void fake_fun()
{
}
