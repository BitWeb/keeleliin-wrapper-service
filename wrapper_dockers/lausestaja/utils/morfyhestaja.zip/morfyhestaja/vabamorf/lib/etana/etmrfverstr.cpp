const char *etMrfVersionString = " XXX ";
